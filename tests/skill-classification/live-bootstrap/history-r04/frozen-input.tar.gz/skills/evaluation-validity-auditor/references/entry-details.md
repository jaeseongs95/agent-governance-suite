## 입력과 단계

`EvaluationValidityRequest.v1`과 하나의 명시적 artifact root를 받는다. 모든 locator는 이 root 안의 상대 경로여야 한다.

- `pre-execution`에서는 동결 시점, case inventory, 역할 독립성, 판정 방법, artifact digest와 provenance를 확인한다. 이 단계의 `PASS`는 결과 유효성을 인증하지 않는다.
- `post-execution`에서는 같은 검사를 다시 수행하고 모든 run·case·criterion, 실패·timeout, 결과 레코드와 공개 집계를 재계산한다. 품질 또는 릴리스 근거로는 이 단계의 `PASS`만 사용한다.

판정 전에 [감사 프로토콜](audit-protocol.md)을 읽는다. 결정적 검사는 CLI로 실행한다.

```bash
node scripts/cli.mjs --input request.json --artifact-root evidence
node scripts/digest-request.mjs --input request.json
node scripts/validate-report.mjs --request request.json --request-artifact request-artifact.json --report report.json --artifact-root evidence
node scripts/cli.mjs --input request.json --artifact-root evidence --format human-ko
node scripts/validate-report.mjs --request request.json --request-artifact request-artifact.json --report report.json --artifact-root evidence --format human-ko
```

기계 소비에는 기본 JSON 출력을 사용한다. 사람에게는 `--format human-ko`의 결론·이유·검증 범위·한계를 한국어로 전달한다. 저장된 보고서는 `validate-report.mjs`로 현재 요청·증거와 다시 대조한 뒤 설명한다. 한국어 설명은 고정 검사 결과를 풀어 쓰는 표시이며 새 평가·소스 검증·릴리스 승인이 아니다. 미실행 검사나 `BLOCKED`·`FAIL`을 통과로 바꾸지 않는다.

## 불변조건

- 의미 보존이나 품질 criterion을 문자열 일치 또는 자기보고만으로 통과시키지 않는다. 명시적인 deterministic criterion에는 lexical match를 허용한다.
- rubric, fixture manifest, oracle, aggregation rule, target revision과 결과 digest를 보고서에 함께 결속한다.
- 누락·중복·unknown case/run/criterion과 malformed JSONL이 있으면 전체 결과를 집계하지 않는다.
- 평가 시작 뒤 관측된 control artifact가 입력에 영향을 주면 `FAIL`, 독립적인 timing provenance가 없으면 `BLOCKED`다.
- 감사자와 의미 판정자를 작성자·실행자와 분리한다. actor ID와 provenance source는 협력적 호출자가 제공한 주장임을 limitation으로 보존한다.
- 기계 보고서 JSON에는 corpus, 정답, prompt, 모델 출력 또는 자유형 finding을 넣지 않는다. 고정 schema·코드·원래 분모와 수량·digest·opaque evidence reference를 보존한다. 사람용 설명은 이 경계를 유지하며 고정 코드의 뜻과 한계를 한국어 문장으로 전달한다. 증거 원문이나 비밀을 설명에 복사하지 않는다.
