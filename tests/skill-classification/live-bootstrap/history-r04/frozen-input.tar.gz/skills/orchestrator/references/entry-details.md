## 실행 class와 단계 구성

`orchestrated` workflow를 실제 실행하거나 실패 뒤 다시 실행할 때는 먼저 [수렴 가드 계약](convergence-guard.md)을 읽고 같은 `rootId`를 유지한다. 단순 조회나 전문 스킬 단독 호출에는 수렴 root를 만들지 않는다.

`executionClass`별로 흐름을 분리한다.

- `bootstrap`: `plan_workflow` 전에 실행한다. `phaseOrder` 순으로 지침 범위를 확인하고, 신뢰할 수 있는 현재 선택값이 있을 때 모델·추론 수준 적합성을 평가하며, 필요할 때 저장소 관례를 조사한 뒤 유효한 `TaskEnvelope.v1`과 수용 근거 계획을 만든다. 이미 같은 대상과 지침 revision에 대해 검증된 산출물이 있으면 중복 실행하지 않는다.
- `workflow`: 동결된 `TaskEnvelope.v1`에서 필요한 capability만 선택한다. `phaseOrder`와 artifact 의존성을 함께 지키며, 첫 변경 전 기준선, 위험한 상태 변경 직전 precondition gate, 구현 후 범위·수용 근거 확인, 마지막 완료 gate 순서를 유지한다.
- `recovery`: 기존 run의 실패 기록을 바꾸지 않고 별도 workflow로 실행한다. 반복 실패가 없으면 미리 넣지 않으며, recovery provider와 일반 workflow provider를 한 run에 섞지 않는다. `blocker-diagnostician`이 `CAUSE_CONFIRMED`를 반환한 뒤에만 별도의 recovery run에서 `recovery-strategy-selector`를 실행한다. 검증된 `RecoveryHandoff.v1`은 새 작업 계약의 입력일 뿐 권한이나 실행 승인이 아니며, 새 `TaskEnvelope.v1` 결속 검사 전에는 후속 workflow를 시작하지 않는다.

첫 수정·표적 시험 실패는 원 오류와 관측을 확인하고 기존 요청·권한 안에서 원인을 고친 뒤 관련 시험으로 검증한다. 한 번 실패했다는 이유로 새 계약, recovery workflow나 `blocker-diagnosis`를 먼저 요구하지 않는다. 같은 안정된 실패가 반복되거나 adapter·운영체제·패키징·호스트·시험·evidence의 상충으로 원인을 구별할 새 검사가 필요할 때 `blocker-diagnosis`를 선택한다. 새 관측이나 입력 변화가 없는 같은 검사를 반복하지 않는다. 확정 원인은 증상→메커니즘→근본 조건과 판별·제거 관측을 보존한 경우에만 별도 recovery 선택의 입력이 된다.

여러 provider가 같은 스킬에 있어도 각 provider의 capability, phase, 입력·출력 artifact를 독립 단계로 취급한다. 스킬 디렉터리명이나 배열 위치로 순서를 추측하지 않는다.

에이전트 간 이견이나 통합 대상 변경으로 기준선을 재배치할 때는 [협업 상세 계약](collaboration.md#전체-최적화와-기준선-재배치)을 먼저 읽는다.

## 초기 라우팅

선택 결과에는 선택한 capability·provider·phase와 이유, 적용 조건에 가까웠지만 생략한 capability와 그 이유를 남긴다. 요청에서 capability를 고르는 판단은 이 지침의 책임이다. MCP 계획기는 `TaskEnvelope.v1.requiredCapabilities`를 provider로 결정적으로 매핑하고 계획·단계·결과의 순서와 근거만 검사하므로, 선택 의미를 계획기로 옮기거나 계획 호출을 선택 근거로 대신하지 않는다.

라우팅 전에 설치 시 노출된 스킬 설명으로 후보 capability를 정하고 `node scripts/query-registry.mjs --capability <capability>`를 실행해 일치하는 활성 provider만 조회한다. 여러 capability는 `--capability`를 반복한다. 후보를 특정할 수 없을 때만 `--all`로 compact 전체 목록을 조회하며, `skills/registry.json` 원문 전체를 모델 컨텍스트로 읽지 않는다. 조회 결과의 `selectionCriteria`, precondition, priority를 선택 설명에 남긴다. 같은 capability의 후보 중 priority가 가장 큰 항목을 선택하되, 동률이나 descriptor 충돌은 임의로 고르지 말고 `needs-input`으로 돌린다. `selectionCriteria`는 사람이 검토하는 근거이며 런타임 필터가 아니다. 필요한 역할이 없으면 `missingCapabilities`, 가능한 직접 스킬 호출 경로와 부족한 capability를 분리해 설명한다.

초기 정책 capability는 `subagent-coordination`, `independent-deliberation`, `independent-audit`다. 일반 변경 흐름에 필요한 모델·추론 수준 적합성, 지침 범위, 작업 계약, 저장소 관례, 변경 기준선·범위 확인, mutation 사전 점검, 수용 근거 확인과 실패 진단도 capability로 찾는다. 현재 provider 이름을 라우팅 조건으로 사용하지 않는다. `task-contract-definition`, `change-scope-baseline-capture`, `change-scope-assurance`, `acceptance-evidence-validation`, `mutation-risk-preflight`, `independent-audit`는 각 descriptor의 적용 조건과 phase가 가리키는 시점에만 선택하며, 모든 요청에 기본으로 붙이지 않는다.

첫 라우팅에서 `CollaborationDecision.v1`을 `schemaVersion: "1.2.0"`으로 만든다. 기존 `1.0.0`과 `1.1.0` 기록은 당시 의미로 검증하며 새 결정은 현재 입력으로 만든다. 결정에는 출처 주장인 `sourceOriginKind`, 관측 가능한 경우의 `sourceReceiptId`, 항상 `none`인 `authorityEffect`, `userDirective`(`require | forbid | unspecified`), 다섯 위임 조건과 독립 감사 분리 필요 여부를 기록한다. 출처 판단과 검증에는 [입력 출처 규칙](input-origin.md)을 적용한다. 결정적 validator가 `direct | delegate | audit-only | needs-input`을 도출하되 결정 artifact와 TLS 메시지는 권한을 만들지 않는다.

구조·라우팅만 검사할 때는 결정 JSON을 stdin으로 [검증 CLI](../scripts/validate-collaboration-decision.mjs)에 전달한다. 영수증 관측까지 확인하려면 읽기 전용 `validate_collaboration_decision` 도구를 사용한다. CLI의 `structural-only` 결과를 영수증 검증이나 사용자 승인 증명으로 해석하지 않는다.

다음 순서로 분류한다.

1. 사용자가 특정 전문 스킬을 명시했으면 해당 스킬의 적용 조건을 확인하고 그 스킬을 호출한다. 요청과 무관한 capability를 덧붙이지 않되, 그 스킬이나 요청된 흐름에 필요한 승인·검증·독립성 gate는 면제하지 않는다.
2. 그 밖의 전문 기능은 요청의 목표와 수용 기준에서 capability를 추출하고 레지스트리 descriptor로 찾는다. 선택한 capability, provider, phase와 선택 이유를 계획에 남긴다.
   `evaluation-validity-audit`를 선택할 때는 공유 `TaskEnvelope.v1`을 변경하지 않는다. `plan_workflow`에 `{ schemaVersion, taskEnvelope, evaluationAuditPurpose }` 구조를 넘기고, 실행 전 설계 감사면 `evaluationAuditPurpose`를 `design-readiness`로, 평가 결과를 품질·릴리스 근거로 제출하는 감사면 `quality-or-release`로 고정한다. 후자는 `post-execution PASS`와 `qualifiesAsQualityOrReleaseEvidence: true`가 모두 확인되지 않으면 완료하지 않는다.
3. 호스트 runtime metadata, 사용자 텍스트나 이번 요청의 화면 캡처에서 현재 task의 모델과 추론 수준을 모두 관측한 경우 `model-effort-fit-assessment`를 요청한다. 현재 선택이 없으면 일반 direct 작업에서는 이 capability 때문에 묻거나 작업을 멈추지 않으며, 결과가 `ADEQUATE`이면 사용자 안내를 생략한다. 단, MCP `orchestrated` workflow를 계획할 때는 별도 규칙을 적용한다. caller는 `plan_workflow` 인자에 `executionContext`를 넣지 않는다. 현재 bootstrap 실행에 대한 model class·추론 수준과 task 결속은 호스트가 서버 측 `TrustedExecutionContextProvider`를 통해 authoritative observation으로 제공해야 한다. provider가 없거나 관측값이 최소 semantic assurance 하한보다 낮아 MCP가 `BINDING_REQUIRED` 또는 `BINDING_INVALID`를 반환하면 값을 임의로 보정·추정하지 않고 해당 workflow를 시작하지 않는다.
4. `CollaborationDecision.v1.route`가 `delegate`인 경우에만 `subagent-coordination`을 `TaskEnvelope.v1.requiredCapabilities`에 명시한다. `auditSeparationRequired`는 route와 독립된 의무다. `delegate`와 함께 참이면 구현 위임과 별도 감사자를 모두 계획한다. `audit-only`는 구현 위임 없이 감사 의무만 남은 경우다. 감사자는 구현에 참여하지 않고 최종 후보가 준비된 뒤 감사하며, 사용자 금지나 실행 불가가 있으면 감사 완료로 처리하지 않는다. 작업 단위가 둘 이상이거나 `orchestration.requested: true`라는 사실만으로 추가하지 않는다.
5. 실제로 양립할 수 없는 대안이나 충돌하는 근거 중 하나를 선택해야 하고, 독립 관점과 교차 반박이 그 선택에 필요한 경우에만 `independent-deliberation`을 `TaskEnvelope.v1.requiredCapabilities`에 명시한다. `decision.complexity: complex`만으로 추가하지 않으며, 이 단계는 구현이나 완료 게이트를 대체하지 않는다.
6. 정확한 최종 대상이 있는 고위험 변경의 실행·병합·릴리스·완료 가능 여부를 판정하는 요청에는 `independent-audit`을 추가한다. 감사 전의 구현·수정·자체 검증은 이 provider의 역할이 아니다.
7. [공통 접수·선택 기준](../SKILL.md#공통-접수선택-기준)에서 코딩 단계가 선택됐으면 `minimal-implementation`을 `TaskEnvelope.v1.requiredCapabilities`에 명시한다. 이 단계는 변경 전 기준선 뒤, 위험한 상태 변경의 사전 점검과 범위·수용 근거 확인 전에 실행된다. 구현 단계에서는 Git이 추적하는 파일의 편집·삭제, 새 파일 생성, 확인용 테스트·빌드 실행만 한다. 추적되지 않는 기존 파일이나 저장소 밖 대상의 삭제·덮어쓰기, 마이그레이션·데이터 변경의 실제 실행, 배포·태그처럼 별도 승인 경계에 있는 작업은 필요한 사전 점검 뒤에 실행한다. 시험 실행, 작업 브랜치의 커밋·push와 CI 실행에는 추가 PRE나 승인을 요구하지 않는다. MCP 계획에 실제 상태 변경에 필요한 stage가 없으면 그 변경을 실행하지 않고 최종 결과에 남은 작업으로 적는다. provider는 필요 없는 기능·추상화·의존성을 만들지 않는 가장 단순한 구현을 고르고, 의도적으로 뺀 것을 결과에 남긴다. MCP 없이 직접 진행할 때도 구현 단계에서 이 capability의 provider를 호출한다. 동결된 `TaskEnvelope.v1`의 범위와 수용 기준은 명시적 요청으로 보고 줄이지 않으며, 줄일 후보는 최종 결과에 제안으로만 남긴다. 검사용 테스트를 포함한 새 파일은 `scope.included`·`workUnits[].writeTargets` 안에서 저장소의 기존 테스트 관례와 위치를 따라 만든다. 작업 계약이 없으면 사용자 요청이 정한 범위를 같은 기준으로 삼는다. 코드 리뷰·감사·검증·완료 판정, 코드 설명·조사만 하는 요청, 코딩이 아닌 요청과 검토·감사를 맡은 하위 실행에는 이 capability를 선택하지 않는다.
8. 단독 전문 작업과 스킬 생략은 [공통 접수·선택 기준](../SKILL.md#공통-접수선택-기준)을 따르고 수렴 root나 workflow run을 만들지 않는다.

이 스킬을 사용했다는 사실은 MCP `executionMode`나 `CollaborationDecision.v1.route`를 정하지 않는다. 실행 방식은 선택한 capability와 `riskLevel`·`orchestration`을 담은 `TaskEnvelope.v1`로 기존 계획기가 정하고, 위임 여부는 위임 판단 규칙이 따로 정한다. `orchestration.requested: true`는 실패 영향이 크고 순서·gate 연결이 필요한 전문 단계가 둘 이상이며 MCP를 사용할 수 있을 때 적는다. 계획기는 이 값으로 `orchestrated`와 `direct`를 나누므로 `false`이면 direct 계획이 돌아온다.

통합 워크플로에서는 bootstrap을 마친 뒤 작업 단위 조정, 독립 숙고, 변경 전 기준선, 최소 구현, 위험한 상태 변경 직전의 사전 점검, 요청된 전문 작업, 범위·수용 근거 확인, 최종 고위험 감사 순으로 연결한다. 구체적인 순서는 provider의 `phaseOrder`와 artifact 의존성으로 정하며 MCP stage 순서와 같아야 한다. 각 전문 스킬이 이미 내부적으로 worker를 조정하는 경우에는 같은 단위를 다시 배정하지 않는다.

위임 여부를 결정하기 전에 [협업 상세 계약의 위임 판단](collaboration.md#위임-판단)을 읽고 자동·명시적 위임의 조건과 예외를 적용한다.

## 실행 순서와 입출력 연결

- 각 단계마다 담당 스킬, 입력 출처, 기대 산출물, 다음 단계와 중단 조건을 기록한다.
- provider가 선언한 `inputBindings`의 `select`, `collect`, `combine`, `require-external`만 사용한다. 누락된 입력을 새로 만들거나 다른 artifact로 조용히 대체하지 않는다.
- 전문 스킬 결과는 선언된 `ProviderResult.v1` envelope로 연결한다. `outputSchema`, `resultSchema`, `stateMapping`을 통과하지 못한 결과를 다음 단계의 입력으로 사용하지 않는다.
- MCP 계획 stage에 `executionRequirement`가 있으면 그 stage를 요구 하한을 충족하는 실행자 설정으로 수행하되, caller는 `StageResult.v1`이나 `record_stage_result` 인자에 `executionContext`를 넣지 않는다. 실제 실행자의 model class·추론 수준과 정확한 run·stage·revision 결속은 호스트가 서버 측 `TrustedExecutionContextProvider`를 통해 관측한다. 현재 세션 값, 다른 worker 값이나 모델 이름에서 추측한 class를 caller 입력으로 대신하지 않는다. semantic stage의 관측값이 없거나 하한 미달이면 MCP의 `BINDING_REQUIRED` 또는 `BINDING_INVALID`를 그대로 처리하고 `passed`로 진행하지 않는다. `korean-prose-finalization`처럼 계획이 `deterministic`으로 표시한 stage에는 이 관측값을 요구하지 않는다.
- 한 스킬의 결과를 다음 스킬에 전달할 때는 확인한 사실, 대상 식별자, 원시 증거 위치, 열린 제한사항을 보존한다. 요약으로 원시 결과나 불확실성을 대체하지 않는다.
- 하위 실행에는 전체 대화를 기본 상속하지 않는다. 목표, 성공 조건, 책임 범위, 원자료 위치, 확정된 결정, 검증과 반환 형식만 담은 제한된 brief를 사용한다. 전체 대화가 없으면 정확성을 유지할 수 없는 경우에만 예외 사유를 기록하고 상속한다.
- 큰 로그와 전문 결과는 artifact 참조와 digest로 전달하고, 상위 컨텍스트에는 결론, 근거 위치와 미해결 사항만 유지한다.
- 이전 단계의 필수 입력이 없거나 결과가 실패·차단 상태이면 그 의존 단계는 실행하지 않는다. 이미 확인된 결과와 누락된 입력을 구분해 보고한다.
- 독립 감사가 필요한 흐름에서는 구현자와 감사자를 분리하고, 감사 후 의미 있는 변경이 생기면 감사 대상과 판정을 다시 연결한다.
- 같은 명령, 입력·candidate digest, 실패 원인과 판별 가설이 모두 그대로라면 다시 실행하지 않는다. 다른 원인 가설을 가르는 검사가 없으면 해당 단계만 중단하고 실패 근거와 필요한 새 입력을 보고한다.

`independent-deliberation` 또는 `independent-audit` provider를 호출하기 전에 [전문 단계 handoff 계약](specialist-handoffs.md)에서 해당 절을 읽고 입력, 결과 투영과 진행 조건을 적용한다.

## 결과 통합

보안 전문 분석을 요청했거나 수용 기준에서 요구하면 `software-security-audit`를 선택한다. 보안 관련 파일의 존재만으로 추가하지 않는다. phase 65의 `security-audit-request`에는 실제 파일 내용을 고정한 대상과 허용 범위를 전달한다. 보고서는 로컬 CLI로 대상·근거를 검증하고 원자료를 확인한 뒤 기록한다. 이 provider의 `passed`는 조사 산출물 생성 성공이며 안전 판정이 아니다. `partial`의 미검사 항목과 limitations를 생략하지 않는다.

수용 근거 검증도 선택됐다면 `security-audit-report` artifact의 locator·digest·targetDigest와 원시 근거를 기존 `workflow:verification-evidence`에 추가하고 해당 보안 수용 기준에 연결한다. 기준 불충족과 검사 공백은 기존 수용 검증·독립 감사 게이트에서 판단한다. 취약점 심각도만으로 전역 차단 정책을 새로 만들지 않는다. 감사 후 대상 변경이 있으면 영향받은 분석과 근거 결속을 다시 확인한다.

## MCP 도구 사용 계약

MCP로 계획·실행·결과 기록을 하기 전에 [MCP 실행 계약](mcp-execution.md)을 읽는다. 연결과 도구 스키마를 확인한 뒤 계약의 호출 순서, revision, compact 응답과 실패 처리를 따른다.

MCP를 사용할 수 없어도 설치된 전문 스킬로 독립 처리 가능한 부분은 진행한다. 필요한 통합 실행 자체가 불가능할 때만 통합 결과를 `BLOCKED`로 보고하며, 직접 실행 결과를 guarded 완료 근거로 표현하지 않는다.

## CS Engineering 연결 (AGS 2.8.0 후보)

정확성에 관련 CS 조건이 필요한 동작 변경이면 `cs-constraint-derivation`을 bootstrap 25에서
선택하고, 핵심 5분야20규칙과 추가 draft5분야를 구분한다. 실제 관련 분야만 로딩한다.
[2.x 인계·리뷰 계약](../../cs-engineering/references/ags-2x-integration.md)을 읽고
READY 조건을 task-contract에 전달해 사용자 요구·수용 기준·검증 계획의 출처로 기록한다.
TaskEnvelope.v1을 바꾸지 않고 최종 task digest로 binding을 만든다.

`handoff`로 동결 입력을 재검사하고 같은 reference/digest와 required obligation ID를
ponytail의 구현 지시로 넘긴다. 수신자는 원자료 접근과 조건 수신을 확인한다. 기존
ponytail inputBindings는 유지되며 모든 구현의 자동 인계 증명으로 표현하지 않는다.

리뷰 capability만 workflow에 요청한다. 선택된 phase67의 MCP stage는
`cs-review-bundle`과 `cs-review-report` artifact를 받아 CLI로 task·후보·조건·원시
파일을 기록 시와 finalize 시 재검사한다. FAIL·BLOCKED를 PASS로 바꾸지 않는다.
같은 의무 ID와 실제 원시 근거를 기존 수용 근거 검증에 연결하고 보안·독립 감사 책임을 유지한다.

계획·lease·start·resume 전체 binding과 전역 적용성·acceptance 강제 정책은 미구현이다.
unknown field를 삭제해 약한 경로로 재시도하지 않는다. 직접 CLI 결과와 선택된
MCP stage 검증·실호스트 자동 선택·독립 감사를 각각 구분한다.

## AGS Engineering Practices v0.1.0

테스트 작성·보강 요청이면 test-engineering을 선택한다. 같은 테스트가 실제 결함에서 실패하는지 확인할 때는 test-sensitivity-review를, prepared test plan의 계약 검사에는 test-plan-validation을 선택한다. 고정된 diff·patch·PR 리뷰에는 code-review/change-code-review를 선택한다. 단순 문구 수정·설명이나 순수 제품 구현에 두 검증 단계를 일률적으로 추가하지 않는다. 입력 자료는 새 스킬의 SKILL.md와 integration descriptor로 확인한다.

작업 조건에 맞는 [Engineering Practices index](engineering-practices/index.md)의 모듈만 읽어 기존 담당자에게 근거와 함께 전달한다. 실패 판별은 blocker-diagnostician/debugging, 구현 단순화는 ponytail/implementation, 의존성·에이전트 확장 변경은 software-security-auditor/dependency, 완료 근거 대조는 acceptance-evidence-validator/verification, 스킬 작성은 agent-instructions로 연결한다. 기존 전문 스킬을 직접 호출한 경로에서는 필요한 참조도 명시한다.

기존 cs-engineering 보고서가 있으면 불변조건·검증 의무 ID를 참조하고 새 규칙으로 교체하지 않는다. 새 권한·PEER·세션 배분·감사 정책은 만들지 않는다. prepared artifacts를 CLI에서 검증한 결과와 원시 근거를 기존 수용/감사 단계에 전달한다. 선택됨·참조 읽음·실행됨·검증됨을 별도로 기록한다. registry 등록과 로컬 CONSISTENT만으로 실제 호스트 활성화나 독립 감사 PASS를 주장하지 않는다.
